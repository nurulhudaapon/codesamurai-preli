// export prisma client to be used in other files
import { PrismaClient } from "@prisma/client"

export const prisma = new PrismaClient()
