Team Name: Green Thunder
Institute Name: Green University of Bangladesh
Team Members:
- Nurul Huda (me@nurulhudaapon.com)
- Zahin Afsar (afsarzahin@gmail.com)
- Suaeb Ahmed (suaebahmed12@gmail.com)